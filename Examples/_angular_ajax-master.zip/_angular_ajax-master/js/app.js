var app = angular.module('myApp', ['players', 'tabs']);

app.controller('BaseController', function() {
});