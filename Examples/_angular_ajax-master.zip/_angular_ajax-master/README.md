# Angular JS AJAX Request

This repository shows a basic AJAX request through Angular.

You can clone this repository and use it as a starting point for an exercise or project.
